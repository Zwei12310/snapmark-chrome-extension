// SnapMark - Background Service Worker
// 处理截图请求、存储管理、分享链接生成

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'capture') {
    // sender.tab 在 popup 中为 undefined，通过 query 获取当前窗口
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const windowId = tabs[0]?.windowId;
      if (!windowId) {
        sendResponse({ error: '无法获取当前窗口' });
        return;
      }
      chrome.tabs.captureVisibleTab(windowId, { format: 'png' }, (dataUrl) => {
        if (chrome.runtime.lastError) {
          sendResponse({ error: chrome.runtime.lastError.message });
          return;
        }
        sendResponse({ dataUrl });
      });
    });
    return true;
  }

  if (request.action === 'download') {
    chrome.downloads.download({
      url: request.dataUrl,
      filename: request.filename || `snapmark-${Date.now()}.png`,
      saveAs: false
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        sendResponse({ error: chrome.runtime.lastError.message });
        return;
      }
      sendResponse({ downloadId });
    });
    return true;
  }

  if (request.action === 'saveHistory') {
    chrome.storage.local.get({ history: [] }, (result) => {
      const history = result.history;
      history.unshift({
        id: Date.now(),
        dataUrl: request.dataUrl,
        url: request.url,
        title: request.title,
        timestamp: new Date().toISOString()
      });
      // 最多保留 50 条
      if (history.length > 50) history.length = 50;
      chrome.storage.local.set({ history }, () => sendResponse({ success: true }));
    });
    return true;
  }

  if (request.action === 'getHistory') {
    chrome.storage.local.get({ history: [] }, (result) => {
      sendResponse({ history: result.history });
    });
    return true;
  }

  if (request.action === 'deleteHistory') {
    chrome.storage.local.get({ history: [] }, (result) => {
      const history = result.history.filter(item => item.id !== request.id);
      chrome.storage.local.set({ history }, () => sendResponse({ success: true }));
    });
    return true;
  }

  if (request.action === 'openEditorAfterCapture') {
    // 1. 保存历史
    chrome.storage.local.get({ history: [] }, (result) => {
      const history = result.history;
      history.unshift({
        id: Date.now(),
        dataUrl: request.dataUrl,
        url: request.url,
        title: request.title,
        timestamp: new Date().toISOString()
      });
      if (history.length > 50) history.length = 50;
      chrome.storage.local.set({ history });
    });

    // 2. 获取当前 tab 并注入编辑器
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      const tabId = tabs[0].id;

      chrome.tabs.sendMessage(tabId, {
        action: 'openEditor',
        dataUrl: request.dataUrl
      }, (response) => {
        // content script 可能尚未注入，尝试用 scripting 注入后再发
        if (chrome.runtime.lastError) {
          chrome.scripting.executeScript({
            target: { tabId },
            files: ['src/content.js']
          }, () => {
            chrome.scripting.insertCSS({
              target: { tabId },
              files: ['src/content.css']
            }, () => {
              chrome.tabs.sendMessage(tabId, {
                action: 'openEditor',
                dataUrl: request.dataUrl
              });
            });
          });
        }
      });
    });
  }
});
